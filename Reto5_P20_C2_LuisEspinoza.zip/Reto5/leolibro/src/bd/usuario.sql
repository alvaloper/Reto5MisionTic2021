CREATE TABLE usuario (
    rut varchar(100) NOT NULL,
    nombre varchar(100)  NOT NULL,
    fecha_prestamos date  NOT NULL,
    PRIMARY KEY (rut)
);
