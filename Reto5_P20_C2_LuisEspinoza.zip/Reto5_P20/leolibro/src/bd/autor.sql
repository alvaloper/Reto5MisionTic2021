CREATE TABLE autor (
    idAutor int(10) NOT NULL AUTO_INCREMENT,
    autor varchar(100)  NOT NULL,
    PRIMARY KEY (idAutor)
);
